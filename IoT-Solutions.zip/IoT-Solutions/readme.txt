IoT-Repositories sample code.
Simulates IoT sensor readings and publishes them using MQTT to a public broker.
