import time, json, random
import paho.mqtt.client as mqtt

client = mqtt.Client()
client.connect("broker.hivemq.com", 1883, 60)

while True:
    sensor_data = {
        "temperature": round(random.uniform(20, 35), 2),
        "humidity": round(random.uniform(40, 60), 2)
    }
    payload = json.dumps(sensor_data)
    client.publish("demo/iot/sensors", payload)
    print("Published:", payload)
    time.sleep(2)
