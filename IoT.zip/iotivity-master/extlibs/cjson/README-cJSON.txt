This dependency comes from: https://github.com/DaveGamble/cJSON.git. The
cJSON.c and cJSON.h files are copied from that repo.

Commit ID from when files were last copied: b0db7a6308f8948dd4a68f06b787cb425ce7254d
Release tag when files were last copied (if applicable):

With the following changes:
* b0db7a6 cJSON_ParseWidthOpts: Fix -Wmissing-field-initializers

